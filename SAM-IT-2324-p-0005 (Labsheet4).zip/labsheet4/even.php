<?php
$num = 1;
do {
    if ($num % 2 == 0) {
        echo $num . "<br>";
    }
    $num++;
} while ($num <= 10);
?>